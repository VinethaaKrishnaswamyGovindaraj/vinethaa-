import pandas as pd

'''
    Question 1 : Mean & Covariance
'''
excel_dataA = pd.read_excel('/Users/vinethaa/Desktop/asgn1/dataA.xlsx', header=None)
# Mean
df_mean = pd.DataFrame(excel_dataA.mean(axis=0))
print('The mean of dataA.xlsx is :')
print(df_mean.transpose())
# Covariance
df_covariance = pd.DataFrame(excel_dataA.cov())
print('The co-variance of dataA.xlsx is :')
print(df_covariance)

'''
    Question 2 : Mean and Covariance
'''
excel_dataB = pd.read_excel('/Users/vinethaa/Desktop/asgn1/dataB.xlsx', header=None)
# Mean
df_mean = pd.DataFrame(excel_dataB.mean(axis=0))
print('The mean of dataB.xlsx is :')
print(df_mean.transpose())
# Covariance
df_covariance = pd.DataFrame(excel_dataB.cov())
print('The co-variance of dataB.xlsx is :')
print(df_covariance)

'''
    Question 3 : Please see krishv8-asgn1-output.txt
'''